Readme.txt

Instructions: 

1.) Navigate to the directory where smallsh.c is located.
2.) Compile the program  enter the following on the command line:

$: gcc -o smallsh smallsh.c

Enter the 



